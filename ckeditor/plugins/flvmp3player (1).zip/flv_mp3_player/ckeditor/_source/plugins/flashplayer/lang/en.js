CKEDITOR.plugins.setLang('flashplayer', 'en',
{
    player :
    {
        flv :
        {
            title : 'video player',
            settings : 'video settings',
            loop : 'loop',
            autoload : 'preload',
            autoplay : 'autoplay',
            iconplay : 'button play',
            format : 'format: (4:3 or 16:9 - in pixel)',
            playerbar : 'playerbar',
            stop : 'button stop',
            volume : 'volume',
            time : 'play time',
            fullscreen : 'fullscreen',
            activ : 'deaktivieren',
            volumestart : 'start volume',
            volumenull : 'mute',
            popup : 'popup box',
            popupdesc : 'open in popup',
            linktxt : 'link text',
            linksource : 'open video'
        },
        mp3 :
        {
            title : 'audio player',
            settings : 'audio- settings',
            loop : 'loop',
            autoload : 'preload',
            autoplay : 'autoplay',
            format : 'player width: (height 20 pixel)',
            pixel : 'pixel',
            playerbar : 'playerbar',
            stop : 'button stop',
            titleinfo : 'title info',
            volume : 'volume',
            volumestart : 'start volume',
            volumenull : 'mute'
        }
    }
});













