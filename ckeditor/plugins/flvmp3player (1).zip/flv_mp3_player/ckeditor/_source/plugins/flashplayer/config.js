
var playerConf = 
{
    color : '6DC018',
    mediapath : 'content/media',
    playerpath : 'includes/javascript/player'
};
