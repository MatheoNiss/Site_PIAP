﻿/**************************************
    Webutler V2.1 - www.webutler.de
    Copyright (c) 2008 - 2011
    Autor: Sven Zinke
    Free for any use
    Lizenz: GPL
**************************************/

CKEDITOR.plugins.setLang('flashplayer','de',{player:{flv:{title:'Videoplayer',settings:'Video-Einstellung',loop:'Loopen',autoload:'Vorladen',autoplay:'Autoplay',iconplay:'Playbutton',format:'Format: (4:3 oder 16:9 - in Pixel)',playerbar:'Abspielleiste',stop:'Stoptaste',volume:'Lautstärke',time:'Spielzeit',fullscreen:'Vollbild',activ:'deaktivieren',volumestart:'Lautstärke-Voreinstellung',volumenull:'aus',popup:'Popupbox',popupdesc:'in Popup öffnen',linktxt:'Linktext',linksource:'Video öffnen'},mp3:{title:'Audioplayer',settings:'Audio-Einstellung',loop:'Loopen',autoload:'Vorladen',autoplay:'Autoplay',format:'Playerbreite: (Höhe 20 Pixel)',pixel:'Pixel',playerbar:'Abspielleiste',stop:'Stoptaste',titleinfo:'Titelinfo',volume:'Lautstärke',volumestart:'Lautstärke-Voreinstellung',volumenull:'aus'}}});
