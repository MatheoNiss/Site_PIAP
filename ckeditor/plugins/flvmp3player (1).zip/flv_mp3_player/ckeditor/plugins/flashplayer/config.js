﻿/**************************************
    Webutler V2.1 - www.webutler.de
    Copyright (c) 2008 - 2011
    Autor: Sven Zinke
    Free for any use
    Lizenz: GPL
**************************************/

var playerConf={color:'6DC018',mediapath:'content/media',playerpath:'includes/javascript/player'};
