﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'toolbar', 'eo', {
	toolbarCollapse: 'Faldi la ilbreton',
	toolbarExpand: 'Malfaldi la ilbreton',
	toolbarGroups: {
		document: 'Dokumento',
		clipboard: 'Poŝo/Malfari',
		editing: 'Redaktado',
		forms: 'Formularoj',
		basicstyles: 'Bazaj stiloj',
		paragraph: 'Paragrafo',
		links: 'Ligiloj',
		insert: 'Enmeti',
		styles: 'Stiloj',
		colors: 'Koloroj',
		tools: 'Iloj'
	},
	toolbars: 'Ilobretoj de la redaktilo'
} );
