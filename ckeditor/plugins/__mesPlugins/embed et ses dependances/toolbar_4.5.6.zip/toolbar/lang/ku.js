﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'toolbar', 'ku', {
	toolbarCollapse: 'شاردنەوی هێڵی تووڵامراز',
	toolbarExpand: 'نیشاندانی هێڵی تووڵامراز',
	toolbarGroups: {
		document: 'پەڕه',
		clipboard: 'بڕین/پووچکردنەوە',
		editing: 'چاکسازی',
		forms: 'داڕشتە',
		basicstyles: 'شێوازی بنچینەیی',
		paragraph: 'بڕگە',
		links: 'بەستەر',
		insert: 'خستنە ناو',
		styles: 'شێواز',
		colors: 'ڕەنگەکان',
		tools: 'ئامرازەکان'
	},
	toolbars: 'تووڵامرازی دەسکاریکەر'
} );
