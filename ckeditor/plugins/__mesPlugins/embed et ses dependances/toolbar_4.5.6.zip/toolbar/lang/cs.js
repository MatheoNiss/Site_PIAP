﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'toolbar', 'cs', {
	toolbarCollapse: 'Skrýt panel nástrojů',
	toolbarExpand: 'Zobrazit panel nástrojů',
	toolbarGroups: {
		document: 'Dokument',
		clipboard: 'Schránka/Zpět',
		editing: 'Úpravy',
		forms: 'Formuláře',
		basicstyles: 'Základní styly',
		paragraph: 'Odstavec',
		links: 'Odkazy',
		insert: 'Vložit',
		styles: 'Styly',
		colors: 'Barvy',
		tools: 'Nástroje'
	},
	toolbars: 'Panely nástrojů editoru'
} );
