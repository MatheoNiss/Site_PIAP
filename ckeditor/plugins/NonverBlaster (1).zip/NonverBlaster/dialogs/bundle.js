/* 
 * add default parameters to this file
 */

/**
 * @todo refactoring (tabs):
 * player medias :
 * - media file
 * - hd optionnal alternative
 * - defaultHD option
 * - preview image
 * - player width
 * - player height
 * 
 * player advanced options :
 * - autoplay, loop, showTotalTime, crop
 * 
 * player personalisation tab :
 * - background, control, control-background colors
 * - indent image
 * - play button image selection
 * 
 * media preview tab
 * 
 */


